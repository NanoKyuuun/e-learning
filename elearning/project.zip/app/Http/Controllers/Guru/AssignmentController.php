<?php

namespace App\Http\Controllers\Guru;

use App\Http\Controllers\Controller;
use App\Models\Assignment;
use App\Models\Meeting;
use App\Services\Guru\AssignmentService;
use Illuminate\Http\Request;
use Inertia\Inertia;

class AssignmentController extends Controller
{
    protected $assignmentService;

    public function __construct(AssignmentService $assignmentService)
    {
        $this->assignmentService = $assignmentService;
    }

    public function store(Request $request, Meeting $meeting)
    {
        $validated = $request->validate([
            'title' => ['required', 'string', 'max:150'],
            'instructions' => ['required', 'string'],
            'due_at' => ['required', 'date', 'after:now'],
            'max_score' => ['nullable', 'numeric', 'min:0', 'max:100'],
            'submission_type' => ['required', 'in:file,text,both'],
            'file' => ['nullable', 'file', 'max:5120'], // Max 5MB untuk file soal
        ]);

        $this->assignmentService->createAssignment($meeting, $validated);

        return redirect()->back()->with('success', 'Tugas berhasil dipublikasikan ke siswa.');
    }

    public function submissions(Assignment $assignment)
    {
        // Pastikan guru ini adalah pemilik pengampu tugas ini
        if ($assignment->meeting->teachingAssignment->teacher_id !== auth()->user()->teacher->id) {
            abort(403);
        }

        return Inertia::render('Guru/Assignments/Submissions', [
            'assignment' => $assignment->load(['meeting.teachingAssignment.subject', 'meeting.teachingAssignment.classGroup']),
            'submissions' => \App\Models\AssignmentSubmission::with(['student.user', 'grade'])
                ->where('assignment_id', $assignment->id)
                ->latest()
                ->get(),
        ]);
    }

    public function allSubmissions()
    {
        $teacherId = auth()->user()->teacher->id;

        // Ambil semua submission dari tugas-tugas milik guru ini
        $submissions = \App\Models\AssignmentSubmission::with([
            'student.user', 
            'assignment.meeting.teachingAssignment.subject',
            'assignment.meeting.teachingAssignment.classGroup',
            'grade'
        ])
        ->whereHas('assignment.meeting.teachingAssignment', function($query) use ($teacherId) {
            $query->where('teacher_id', $teacherId);
        })
        ->latest()
        ->paginate(15);

        return Inertia::render('Guru/Assignments/AllSubmissions', [
            'submissions' => $submissions,
        ]);
    }

    public function grading()
    {
        $teacherId = auth()->user()->teacher->id;

        // Ambil semua tugas yang dibuat oleh guru ini
        $assignments = Assignment::with([
            'meeting.teachingAssignment.subject',
            'meeting.teachingAssignment.classGroup'
        ])
        ->withCount([
            'submissions as total_submissions',
            'submissions as graded_submissions' => function($query) {
                $query->whereHas('grade');
            }
        ])
        ->whereHas('meeting.teachingAssignment', function($query) use ($teacherId) {
            $query->where('teacher_id', $teacherId);
        })
        ->latest()
        ->get();

        return Inertia::render('Guru/Assignments/Grading', [
            'assignments' => $assignments,
        ]);
    }

    public function destroy(Assignment $assignment)
    {
        $this->assignmentService->deleteAssignment($assignment);
        return redirect()->back()->with('success', 'Tugas berhasil dihapus.');
    }
}
