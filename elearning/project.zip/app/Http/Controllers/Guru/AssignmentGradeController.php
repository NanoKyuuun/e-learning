<?php

namespace App\Http\Controllers\Guru;

use App\Http\Controllers\Controller;
use App\Models\AssignmentSubmission;
use App\Services\Guru\AssignmentGradeService;
use Illuminate\Http\Request;

class AssignmentGradeController extends Controller
{
    protected $gradeService;

    public function __construct(AssignmentGradeService $gradeService)
    {
        $this->gradeService = $gradeService;
    }

    public function store(Request $request, AssignmentSubmission $submission)
    {
        $validated = $request->validate([
            'score' => ['required', 'numeric', 'min:0', 'max:100'],
            'feedback' => ['nullable', 'string'],
        ]);

        $this->gradeService->gradeSubmission($submission, $validated);

        return redirect()->back()->with('success', 'Nilai berhasil disimpan.');
    }
}
