<?php

namespace App\Http\Controllers\Guru;

use App\Http\Controllers\Controller;
use App\Models\Material;
use App\Models\Meeting;
use App\Services\Guru\MaterialService;
use Illuminate\Http\Request;

class MaterialController extends Controller
{
    protected $materialService;

    public function __construct(MaterialService $materialService)
    {
        $this->materialService = $materialService;
    }

    public function store(Request $request, Meeting $meeting)
    {
        $validated = $request->validate([
            'title' => ['required', 'string', 'max:150'],
            'description' => ['nullable', 'string'],
            'file' => ['nullable', 'file', 'max:10240'], // Max 10MB
            'file_type' => ['nullable', 'string'],
        ]);

        $this->materialService->createMaterial($meeting, $validated);

        return redirect()->back()->with('success', 'Materi berhasil diunggah.');
    }

    public function destroy(Material $material)
    {
        $this->materialService->deleteMaterial($material);
        return redirect()->back()->with('success', 'Materi berhasil dihapus.');
    }
}
