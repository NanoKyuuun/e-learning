<?php

namespace App\Http\Controllers\Kajur;

use App\Http\Controllers\Controller;
use App\Models\ClassGroup;
use App\Models\Subject;
use App\Models\Teacher;
use App\Models\Student;
use App\Models\StudentClassEnrollment;
use Inertia\Inertia;

class DashboardController extends Controller
{
    public function __invoke()
    {
        $deptId = auth()->user()->teacher->department_id;

        return Inertia::render('Kajur/Dashboard', [
            'stats' => [
                'total_classes' => ClassGroup::where('department_id', $deptId)->count(),
                'total_subjects' => Subject::where('department_id', $deptId)->orWhereNull('department_id')->count(),
                'total_teachers' => Teacher::where('department_id', $deptId)->count(),
                'total_students' => StudentClassEnrollment::whereHas('classGroup', function($q) use ($deptId) {
                    $q->where('department_id', $deptId);
                })->count(),
            ]
        ]);
    }
}
