<?php

namespace App\Http\Controllers\Siswa;

use App\Http\Controllers\Controller;
use App\Models\Assignment;
use App\Services\Siswa\AssignmentSubmissionService;
use Illuminate\Http\Request;

class AssignmentSubmissionController extends Controller
{
    protected $submissionService;

    public function __construct(AssignmentSubmissionService $submissionService)
    {
        $this->submissionService = $submissionService;
    }

    public function store(Request $request, Assignment $assignment)
    {
        $validated = $request->validate([
            'submission_text' => ['nullable', 'string'],
            'file' => ['nullable', 'file', 'max:10240'], // Max 10MB
            'student_notes' => ['nullable', 'string', 'max:255'],
        ]);

        $this->submissionService->submitAssignment($assignment, $validated);

        return redirect()->back()->with('success', 'Tugas Anda berhasil dikirim.');
    }
}
